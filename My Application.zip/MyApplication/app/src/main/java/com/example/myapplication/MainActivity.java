package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView username = findViewById(R.id.username);
        TextView password = findViewById(R.id.password);

        Button loginBtn = findViewById(R.id.loginbtn);


        loginBtn.setOnClickListener(e -> {
                    if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin"))
                        Snackbar.make(findViewById(R.id.myCoordinatorLayout), "LOGIN SUCCESFULL",
                                Snackbar.LENGTH_SHORT).show();
                    else if (username.getText().toString().isEmpty() && password.getText().toString().isEmpty())
                        Snackbar.make(findViewById(R.id.myCoordinatorLayout), "USERNAME AND PASSWORD MUST NOT BE EMPTY",
                                Snackbar.LENGTH_SHORT).show();
                    else
                        Snackbar.make(findViewById(R.id.myCoordinatorLayout), "CREDENTIALS INVALID",
                                Snackbar.LENGTH_SHORT).show();
                }
        );
    }
}